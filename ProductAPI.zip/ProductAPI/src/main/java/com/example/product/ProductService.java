package com.example.product;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Autowired;
import java.io.IOException;
import java.util.List;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private JobLauncher jobLauncher;
	@Autowired
	private Job job;
	 
	 
	public List<ProductEntity> getAllProducts() {
		return productRepository.findAll();
	}

	public ProductEntity addNewProduct(ProductEntity productEntity) {
		return productRepository.save(productEntity);
	}

	public ProductEntity getOneProduct(int id) {
		return productRepository.findById(id).orElseThrow(() -> new RuntimeException("Product does not Exist"));
	}

	public ProductEntity updateProduct(ProductEntity productEntity, int id) {
		productEntity.setId(id);
		return productRepository.save(productEntity);
	}

	public void deleteProduct(int id) {
		productRepository.deleteById(id);
	}

	public List<ProductEntity> getByCategory(String category) {
		return productRepository.findAllByCategory(category);
	}

	public List<String> getCategories() {
		return productRepository.findCategories();
	}

	public ResponseEntity<String> startBatch(MultipartFile file) throws Exception { // Modified to accept a file path

		if (!file.isEmpty()) {
			try {
				//List<ProductEntity> products = parseProductsFromFile(file);
				processFile(file);
				return new ResponseEntity<>("Products uploaded successfully", HttpStatus.OK);
			} catch (IOException e) {
				return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			return new ResponseEntity<>("No file selected", HttpStatus.BAD_REQUEST);
		}
	}
	
	 private List<ProductEntity> parseProductsFromFile(MultipartFile file) throws IOException {
	        List<ProductEntity> products = new ArrayList<>();
	        String content = new String(file.getBytes());
	        String[] lines = content.split(System.lineSeparator());
	        boolean firstLine = true;
	        for (String line : lines) {
	        	if(firstLine) {
	        		firstLine = false;
	        		continue;   		
	        	}
	        	System.out.println(line);	 
	        	String[] data = line.split(",");
	        	ProductEntity tempProduct = ProductEntity.builder()
	        			.id(Integer.parseInt(data[0]))
	        			.name(data[1])
	        			.description(data[2])
	        			.price(Double.parseDouble(data[3]))
	        			.category(data[4])
	        			.imageUrl(data[5])
	        			.build();		        		
	            products.add(tempProduct);
	            products.stream().forEach(System.out::println);
	        }

	        return products;
	    }
	 public void processFile(MultipartFile file) throws Exception {
	        try {
	            JobParameters params = new JobParametersBuilder()
	                    .addLong("time", System.currentTimeMillis())
	                    .addString("file", file.getOriginalFilename())
	                    .toJobParameters();

	            jobLauncher.run(job, params);
	        } catch (Exception e) {
	            throw new RuntimeException("Failed to process file", e);
	        }
	    }
	 
	 

}
