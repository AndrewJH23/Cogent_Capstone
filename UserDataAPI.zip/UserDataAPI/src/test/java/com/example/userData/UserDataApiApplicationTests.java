package com.example.userData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserDataApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
