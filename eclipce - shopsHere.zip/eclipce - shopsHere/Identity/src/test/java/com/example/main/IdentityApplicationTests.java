package com.example.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdentityApplicationTests {

	@Test
	void contextLoads() {
	}

}
