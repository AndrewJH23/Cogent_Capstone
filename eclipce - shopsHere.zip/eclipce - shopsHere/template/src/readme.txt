In gateway yml:
-- port number
-- application name
-- allow cirucit breaker: stop stop errors to from not stopping other working sections
-- default filters to expose endpoints to be able to be used in emmbedded project
-- routing section: Identity resources
-- eureka sources
----------
gateway package:
-- application: need discovoryclient, feign client, and springboot application
-- Security client: with validate
------------
Identity:
-- annotation cross origin 