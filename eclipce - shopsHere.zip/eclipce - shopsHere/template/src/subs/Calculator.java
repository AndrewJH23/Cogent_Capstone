package subs;

//Demonstrate method overloading with a class Calculator that has multiple add() methods for different parameter types. 39
public class Calculator {
		
	public float add(Number a, Number b, Number c) {
		return a.floatValue() + b.floatValue() + c.floatValue();
	}
	
	public float add(Number a, Number b) {
		return a.floatValue() + b.floatValue();
	}
}
