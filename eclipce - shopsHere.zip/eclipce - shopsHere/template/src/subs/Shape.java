package subs;
//Define a superclass Shape with a method draw(). Create subclasses Circle, Rectangle, and Triangle that override the draw() method.
abstract class Shape {
	public void draw() {
		System.out.println("drawing");
	}
}
