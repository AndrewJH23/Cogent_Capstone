package subs;

public class Cat extends Animal{
	
	@Override
	public void makeSound() {
		System.out.println("Cat sound");
	}

}
