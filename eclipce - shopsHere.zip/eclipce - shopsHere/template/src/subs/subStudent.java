package subs;

public class subStudent extends Person{
	private String edu;

	public subStudent(Person p, String edu) {
		super(p.getName(),p.getAge());
		this.edu = edu;
	}

	@Override
	public String toString() {
		return "subStudent [edu=" + edu + "]";
	}
	
	

}
