package subs;

public class Car extends Vehicle{
	
	private int wheels;
	
	
	public Car(Vehicle v, int wheels) {
		super(v.getMake(), v.getModel());
		this.wheels = wheels;
	}


	@Override
	public String toString() {
		return "Car [wheels=" + wheels + "]";
	}
	
	
	

}
