package subs;

public class subCircle extends Shape{
	@Override
	public void draw() {
		System.out.println("circle drawing");
	}
}

	
	

