package subs;
//Define a superclass Animal with a method makeSound(). 
//Create subclasses Dog and Cat that override the makeSound() method.
abstract class Animal {
	
	public abstract void makeSound();

}
