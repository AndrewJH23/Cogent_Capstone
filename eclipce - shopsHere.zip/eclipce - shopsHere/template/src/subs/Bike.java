package subs;

public class Bike extends Vehicle{
	private String color;
	
	
	public Bike(Vehicle v, String color) {
		super(v.getMake(), v.getModel());
		this.color = color;
	}


	@Override
	public String toString() {
		return "Bike [color=" + color + "]";
	}
	
	
}

