package subs;

public class Teacher extends Person{
	private String teacher;
	
	public Teacher(Person p, String teacher) {
		super(p.getName(),p.getAge());
		this.teacher = teacher;
	}

	@Override
	public String toString() {
		return "Teacher [teacher=" + teacher + "]";
	}
	
	

}
