package subs;

//Define a class BankAccount with private attributes like accountNumber and balance. 
//Provide public methods to access and modify these attributes.
public class BankAccount {
	private int accountNumber;
	private double balance;
	
	public BankAccount(int id, double bal) {
		this.accountNumber=id;
		this.balance=bal;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
}
