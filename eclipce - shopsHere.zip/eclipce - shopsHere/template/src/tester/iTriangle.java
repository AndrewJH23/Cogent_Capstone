package tester;

public class iTriangle implements ShapeInterface{
	private double a;
	private double b;
	private double c;
	
	public iTriangle(double a, double b, double c){
		this.a=a;
		this.b=b;
		this.c=c;
	}
	
	@Override
	public double calculateArea() {
		// TODO Auto-generated method stub
		double s = (calculatePerimeter()/2);
		return Math.sqrt(s *(s-a)*(s-b)*(s-c));
	}

	@Override
	public double calculatePerimeter() {
		// TODO Auto-generated method stub
		return this.a+this.b+this.c;
		
	}

}
