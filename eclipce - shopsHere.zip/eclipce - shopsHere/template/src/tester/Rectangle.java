package tester;

//Define a class Rectangle with attributes length and breadth and methods to calculate area and perimeter. 
//Create and display objects of this class.
public class Rectangle {
	private double length;
	private double width;
	
	Rectangle(double length, double width){
		this.length =length;
		this.width = width;
	}
	
	public double area() {
		return this.length * this.width;
	}
	
	public double perimeter() {
		return this.length*2 + this.width*2;
	}
	
	public String print() {
		return "length: "+this.length+" width: "+this.width;
	}
}
