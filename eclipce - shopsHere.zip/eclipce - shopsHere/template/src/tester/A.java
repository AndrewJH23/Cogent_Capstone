package tester;

public class A extends methods{

	public static void main(String[] args) throws Exception {
		methods o = new methods();
//		Write a program to check if a number is prime. 1
		o.isPrime(6);
//		Write a program to print the Fibonacci series up to a given number. 2
		o.Fibonacci(7);
//		Write a program to find the factorial of a number. 3
		o.Factorial(5);
//		Write a program to reverse a number. 4
		o.ReverseNumber(123);
//		Write a program to check if a number is a palindrome.  5
		o.Palindrome(123321);
//		Write a program to print the multiplication table of a given number. 6
		o.printMulti(12);
//		Write a program to count the number of digits in a number. 7
		o.DigitCount(1234);
//		Write a program to find the sum of the digits of a number. 8
		o.DigitSum(12345); 
//		Write a program to find the largest element in an array. 9
		int[] ary = {1,9,6,5,3,2,7,8,8,5,9,1,2};
		o.ArrayLargest(ary);
//		Write a program to find the second largest element in an array. 10
		o.ArraySecondLargest(ary);
//		Write a program to find the smallest element in an array. 11
		o.ArraySmallest(ary);
//		Write a program to find the sum of all elements in an array. 12
		o.ArraySum(ary);
//		Write a program to find the average of all elements in an array. 13
		o.ArrayAverage(ary);
//		Write a program to reverse an array. 14
		o.ArrayReverse(ary);
//		Write a program to find the frequency of each element in an array. 15
		o.Arrayfrequency(ary);
//		Write a program to sort an array in ascending order. 16
		o.ArraySortAscend(ary);
//		Write a program to sort an array in descending order. 17
		o.ArraySortDecend(ary);
//		Write a program to remove duplicate elements from an array. 18
		o.ArrayRemoveDupe(ary);
//		Write a program to merge two arrays. 19
		int[] ary2 = {3,4,5,6,7,8,9};
		o.ArrayMerge(ary, ary2);
//		Write a program to find the length of a string. 20
		String str = "There Are Many Different Letters To Print";
		o.StringLength(str);
//		Write a program to concatenate two strings. 21
		String str2 =" and there is a lot to compare";
		o.StringConcat(str, str2);
//		Write a program to compare two strings. 22
		o.StringCompare(str, str2);
//		Write a program to reverse a string. 23
		o.StringReverse(str);
//		Write a program to check if a string is a palindrome. 24
		o.StringPalindrome("RacecaR");
//		Write a program to find the frequency of each character in a string. 25
		o.StringFrequency(str);
//		Write a program to count the number of vowels and consonants in a string. 26
		o.StringVowelConstCount(str);
//		Write a program to convert a string to uppercase and lowercase. 27
		o.StringCase(str);
//		Write a program to replace a character in a string. 28
		o.StringReplace("Mountain", 'M', 'F');
//		Write a program to find a substring in a string. 29
		o.SubstringSearch(str, "Many Different");
//		Define a class Person with attributes like name, age, and address. Create and display objects of this class. 30
		o.Person1("Human", 25, "Earth");
//		Define a class Rectangle with attributes length and breadth and methods to calculate area and perimeter. Create and display objects of this class. 31
		o.Rectangle(12.5, 16.3);
//		Define a class Circle with an attribute radius and methods to calculate area and circumference. Create and display objects of this class. 32
		o.Circle(5.8);
//		Define a class Employee with attributes like name, id, and salary. Create and display objects of this class. 33
		o.Employee("employee", 123, 99_999.99);
//		Define a class Student with attributes like name, roll number, and marks. Create and display objects of this class. 34
		o.Student("student", 88, 98.2);
//		Define a superclass Animal with a method makeSound(). Create subclasses Dog and Cat that override the makeSound() method. 35
		o.Animal();
//		Define a superclass Shape with a method draw(). Create subclasses Circle, Rectangle, and Triangle that override the draw() method. 36
		o.Shape();
//		Define a superclass Vehicle with attributes like make and model. Create subclasses Car and Bike with additional attributes and methods. 37 
		o.Vehicle("Make", "model", 4, "color");
//		Define a superclass Person with attributes like name and age. Create subclasses Teacher and Student with additional attributes and methods. 38
		o.PersonSub("subName", 25, "subTeacher", "highEducation");
//		Demonstrate method overloading with a class Calculator that has multiple add() methods for different parameter types. 39
		o.Calculator(12, 5.3d, 9.2f);
//		Demonstrate method overriding with a superclass Shape and its subclasses Circle, Rectangle, and Triangle. 40
		o.Shape1();
//		Define an abstract class Animal with an abstract method makeSound(). Create subclasses Dog and Cat that implement the makeSound() method. 41
		o.Animal1();
//		Define an interface Shape with methods calculateArea() and calculatePerimeter(). Create classes Circle, Rectangle, and Triangle that implement the Shape interface. 42
		o.iShape(13.5, 5, 6, 3, 4, 5);
//		Define a class BankAccount with private attributes like accountNumber and balance. Provide public methods to access and modify these attributes. 43
		o.BankAccount(1, 250);
//		Write a program to handle ArrayIndexOutOfBoundsException. 44
		o.ExceptionIndex();
//		Write a program to handle NumberFormatException. 45
		o.ExceptionNumber();
//		Write a program to handle NullPointerException. 46
		o.ExceptionNull();
//		Write a program that uses try, catch, and finally blocks. 47
		o.trying();
//		Write a program to create and use a custom exception InvalidAgeException. 48
		o.ExceptionCustom(true);
//		Write a program to demonstrate the use of ArrayList. 49
		o.FrameArrayList();
//		Write a program to demonstrate the use of LinkedList. 50
		o.FrameLinkedList();
//		Write a program to demonstrate the use of HashSet. 51
		o.FrameHashSet();
//		Write a program to demonstrate the use of TreeSet. 52
		o.FrameTreeSet();
//		Write a program to demonstrate the use of HashMap. 53
		o.FrameHashMap();
//		Write a program to demonstrate the use of TreeMap. 54
		o.FrameTreeMap();
//		Write a program to read content from a file. 55
//		Write a program to write content to a file. 56
//		Write a program to copy content from one file to another. 57
//		Write a program to read and write objects to a file using serialization. 58
//		Write a program to create and run multiple threads by extending the Thread class. 59
		o.ThreadExtend();
//		Write a program to create and run multiple threads by implementing the Runnable interface. 60
		o.ThreadInter();
//		Write a program to demonstrate thread synchronization using synchronized methods. 61
		o.ThreadSyncMethod();
//		Write a program to demonstrate thread synchronization using synchronized blocks. 62
		o.ThreadSyncBlocks();
//		Write a program to demonstrate inter-thread communication using wait() and notify() methods. 63
		o.Threadinter();
//		Write a program to demonstrate the use of lambda expressions. 64
		o.lambda();
//		Write a program to demonstrate the use of streams for filtering and mapping. 65
		o.Streams();
//		Write a program to demonstrate the use of method references. 66
		o.MethodRef();
//		Write a program to demonstrate the use of default and static methods in interfaces. 67
		o.defaultStatic();
//		Write a program to demonstrate the use of the Optional class. 68
//		Write a program to demonstrate the use of enums. 69
//		Write a program to demonstrate the use of nested classes. 70
//		Write a program to demonstrate the use of generics.
//		Write a program to demonstrate the use of annotations.
//		Write a program to demonstrate the use of the Reflection API.
//		Write a program to demonstrate the use of the Stream API for parallel processing.
//		Write a program to demonstrate the use of the CompletableFuture class for asynchronous programming.
//		Write a program to connect to a database.
//		Write a program to insert data into a database.
//		Write a program to update data in a database.
//		Write a program to delete data from a database.
//		Write a program to retrieve data from a database.
//		Write a program to use prepared statements to insert and retrieve data from a database.
//		Write a program to use callable statements to call stored procedures.
//		Write a program to calculate the area of different shapes using method overloading.
//		Write a program to demonstrate the use of a final keyword with a variable, method, and class.
//		Write a program to demonstrate the use of a static keyword with a variable and method.
//		Write a program to demonstrate the use of this keyword.
//		Write a program to demonstrate the use of super keyword.
//		Write a program to implement a simple calculator using switch-case statements.
//		Write a program to demonstrate the use of a singleton class.
//		Write a program to demonstrate the use of a factory design pattern.
//		Write a program to demonstrate the use of a builder design pattern.
	}
}
