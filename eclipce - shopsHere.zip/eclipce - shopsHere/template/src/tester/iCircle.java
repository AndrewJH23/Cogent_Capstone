package tester;

public class iCircle implements ShapeInterface {
	private double radius;
	
	public iCircle(double radius){
		this.radius = radius;
	}
	
	@Override
	public double calculateArea() {
		// TODO Auto-generated method stub
		return Math.PI * this.radius * this.radius;

	}

	@Override
	public double calculatePerimeter() {
		return 2 * Math.PI * this.radius;

	}

}
