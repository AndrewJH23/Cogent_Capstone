package tester;

public class multiThread extends Thread {
	
	public void run() {
		System.out.println("running thread");
		for(int i = 0; i <= 5; i++) {
			System.out.print(" " + i);
			try {
				sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		System.out.println();
	}
}
