package tester;

//Define a class Student with attributes like name, roll number, and marks. Create and display objects of this class.
public class Student {
	private String name;
	private int rollnumber;
	private double marks;

	Student(String name, int rollnumber, double marks) {
		this.name = name;
		this.rollnumber = rollnumber;
		this.marks = marks;
	}

	public String print() {
		return "Name: " + this.name + " Roll Number: " + this.rollnumber+ " Marks: " + this.marks;
	}

}
