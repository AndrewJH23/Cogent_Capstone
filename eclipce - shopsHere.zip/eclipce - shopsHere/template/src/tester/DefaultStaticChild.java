package tester;

public class DefaultStaticChild implements DefaultStatics{
	public void print() {
		DefaultStatics.statics();
	}
	
	@Override
	public void def() {
		DefaultStatics.super.def();
	}
}
