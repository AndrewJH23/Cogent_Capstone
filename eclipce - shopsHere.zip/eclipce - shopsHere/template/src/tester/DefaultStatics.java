package tester;

public interface DefaultStatics {
	default void def() {
		System.out.println("default in interface");
	}
	static void statics() {
		System.out.println("static in interfacee");
	}
}
