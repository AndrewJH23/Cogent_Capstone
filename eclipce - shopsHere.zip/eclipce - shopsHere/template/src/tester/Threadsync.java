package tester;

public class Threadsync {
	private boolean ready = false;
	
	public synchronized void loop() {
		for(int i = 0; i <= 5;i++) {
			System.out.print(" | "+i);
		}
	}
	
	public void loop2() {
		for(int i = 5; i >= 0;i--) {
			System.out.print(" | "+i);
		}
	}
	
	public void loop2Caller() {
		synchronized(this) {
			loop2();
		}
	}
	
	public synchronized void waiter() throws InterruptedException{
		while(!ready) {
			System.out.print(" | waiting | ");
			wait();
		}
		System.out.println("signal reccived");
	}
	
	public synchronized void sender() {
		ready = true;
		System.out.println("sending signal");
		notifyAll();
	}

}
