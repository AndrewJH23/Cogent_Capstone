package tester;

public interface ShapeInterface {
//	Define an interface Shape with methods calculateArea() and calculatePerimeter(). 
	//Create classes Circle, Rectangle, and Triangle that implement the Shape interface.
	public double calculateArea();
	
	public double calculatePerimeter();
}
