package tester;
//Define a class Employee with attributes like name, id, and salary. Create and display objects of this class.
public class Employee {
	private String name;
	private int id;
	private double salary;
	
	Employee(String name,int id, double salary){
		this.name=name;
		this.id=id;
		this.salary=salary;
	}
	
	public String print() {
		return "name: "+ this.name + "id: "+this.id+" salary: " + this.salary;
	}

}
