package tester;

public class imultiThread implements Runnable{

	@Override
	public void run() {
		System.out.println("running implemented thread");
		for(int i = 0; i <= 6; i++) {
			System.out.print(", " + i);
		}
		System.out.println();
	}

}
