package tester;
//Define a class Circle with an attribute radius and methods to calculate area and circumference. 
//Create and display objects of this class.
public class Circle {
	private double radius;
	
	Circle(double radius){
		this.radius = radius;
	}
	
	public double area() {
		return Math.PI * this.radius * this.radius;
	}
	
	public double circumference() {
		return 2 * Math.PI * this.radius;
	}
	public String print() {
		return "radius: "+ this.radius;
	}

}
