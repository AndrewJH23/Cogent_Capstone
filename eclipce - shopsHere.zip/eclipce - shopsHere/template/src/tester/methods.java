package tester;

import java.util.*;
import subs.*;

public class methods {
//	Write a program to check if a number is prime.
	public void isPrime(int n) {
		boolean result = true;
		for (int i = 2; i * i < n; i++) {
			if (i % n == 0) {
				result = false;
			}
		}
		System.out.println("the number"+n +" is: " + (result? "":"not") + " a prime number");
	}

//	Write a program to print the Fibonacci series up to a given number.
	public void Fibonacci(int n) {
		int a = 0;
		int b = 1;
		System.out.print("fibonacci series up to "+ n+": ");
		for (int i = 1; i <= n; i++) {
			System.out.print(a + " + ");
			int sum = a + b;
			a = b;
			b = sum;
		}
		System.out.println();
	}

//	Write a program to find the factorial of a number.
	public void Factorial(int num) {
		double result = 1;

		for (int i = 1; i <= num; i++) {
			result *= i;
		}

		System.out.println("Factorial of " + num + " is " + result);
	}

//	Write a program to reverse a number.
	public void ReverseNumber(int num) {
		int reversed = 0;
		
		int origin = num;

		while (num != 0) {
			int digit = num % 10;
			reversed = reversed * 10 + digit;
			num /= 10;
		}

		System.out.println("Reversed "+origin+" is " + reversed);
	}

//	Write a program to check if a number is a palindrome.
	public void Palindrome(int num) {
		int reversed = 0;

		int origin = num;

		while (num != 0) {
			int digit = num % 10;
			reversed = reversed * 10 + digit;
			num /= 10;
		}

		if (origin == reversed) {
			System.out.println(origin+ " is a palindrome.");
		} else {
			System.out.println(origin+ " is not a palindrome.");
		}
	}

//	Write a program to print the multiplication table of a given number.
	public void printMulti(int num) {
		System.out.println("Multiplication table of " + num + " is");
		for (int i = 1; i <= 10; i++) {
			System.out.println(num + " x " + i + " = " + (num * i));
		}
	}

//	Write a program to count the number of digits in a number.
	public void DigitCount(int num) {
			int count = 0;
			
			int origin = num;
			
			while (num != 0) {
				num /= 10;
				count++;
			}

			System.out.println("Number of digits in " + origin + " is " + count);
	}

//	Write a program to find the sum of the digits of a number.
	public void DigitSum(int num) {
			int sum = 0;
			
			int origin = num;
			
			while (num != 0) {
				sum += num % 10;
				num /= 10;
			}

			System.out.println("Sum of digits in " + origin + " is " + sum);
	}

//	Write a program to find the largest element in an array.
	public void ArrayLargest(int[] ary) {
	   //assume non empty array
	    int max = ary[0];
	    for (int i :ary) {
	        if (i > max) max = i;
	    }
	    System.out.println("the largest element is: "+ max);
	}
//	Write a program to find the second largest element in an array.
	public void ArraySecondLargest(int[] ary) {
	    //assume array has at Least two elements
	    int Max1 = -999, Max2 = 999;
	    for (int i :ary) {
	        if (i > Max1) {
	            Max2 = Max1;
	            Max1 = i;
	        } else if (i > Max2 && i!= Max1) {
	            Max2 = i;
	        }
	    }
	    System.out.println("the seccond largest element is: "+ Max2);
	}
//	Write a program to find the smallest element in an array.
	public void ArraySmallest(int[] ary) {
	    //asume ary is not empty
	    int min = ary[0];
	    for (int i :ary) {
	        if (i < min) min = i;
	    }
	    System.out.println("the smallest element is: "+ min);
	}
//	Write a program to find the sum of all elements in an array.
	public void ArraySum(int[] ary) {
		//asume ary is not empty
	    int sum = 0;
	    for (int i :ary) {
	        sum += i;
	    }
	    System.out.println("the array sum is: "+ sum);
	}
//	Write a program to find the average of all elements in an array.
	public void ArrayAverage(int[] ary) {
	    //assume ary not empty
		int sum = 0;
	    for (int i :ary) {
	        sum += i;
	    }
	    double result =  (double) sum /ary.length;
	    System.out.println("the array average is: "+ result);
	}
//	Write a program to reverse an array.
	public void ArrayReverse(int[] ary) {
	    //assume ary is not empty
		int[] result = new int[ary.length];
		
		for(int i = ary.length-1; i >= 0; i--) {
			result[i] = ary[i];
		}
		System.out.println("the array in reverse is: ");
	    for(int p: result) {
	    	System.out.print(" "+ p);
	    }
	    System.out.println();
	}
//	Write a program to find the frequency of each element in an array.
	public void Arrayfrequency(int[]ary) {
Map<Integer, Integer> frequencyMap = new HashMap<>();
        
        // Iterate through the array and update the frequency map
        for (int num : ary) {
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
        }
        
        // Print the frequency of each element
        System.out.println("Frequency of each element:");
        for (Map.Entry<Integer, Integer> entry : frequencyMap.entrySet()) {
            System.out.print(entry.getKey() + ": " + entry.getValue() + " | ");
        }
        System.out.println();
	}
//	Write a program to sort an array in ascending order.
	public void ArraySortAscend(int[] ary) {
	    Arrays.sort(ary); 
	    System.out.println("the array sorted in ascending is: ");
	    for(int p: ary) {
	    	System.out.print(" "+p);
	    }
	    System.out.println();
	}
//	Write a program to sort an array in descending order.
	public void ArraySortDecend(int[] ary) {
	    Arrays.sort(ary);
	    int[] result = new int[ary.length];
		
		for(int i = ary.length-1; i >= 0; i--) {
			result[i] = ary[i];
		}
		System.out.println("the array in descending order is: ");
	    for(int p: result) {
	    	System.out.print(" "+ p);
	    }
	    System.out.println();
	}
//	Write a program to remove duplicate elements from an array.
	public void ArrayRemoveDupe(int[] ary) {
	    Set<Integer> unique = new HashSet<Integer>();
	    for(int i: ary) {
	    	unique.add(i);
	    }
	    int[] result = new int[unique.size()];
	    int index = 0;
	    for (int num : unique) {
	        result[index] = num;
	        index++;
	    }
	    System.out.println("the array without duplicates is: ");
	    for(int p: result) {
	    	System.out.print(" "+ p);
	    }
	    System.out.println();
	}
//	Write a program to merge two arrays.
	public void ArrayMerge(int[] a1, int[] a2) {
	    int[] merged = new int[a1.length + a2.length];
	    
	    int i = 0;
	    while(i < a1.length) {
	    	merged[i] = a1[i];
	    	i++;
	    }
	    int j = 0;
	    while(j < a2.length) {
	    	merged[i] = a1[j];
	    	i++;
	    	j++;
	    }
	    
	    System.out.println("the arrays merged is: ");
	    for(int p: merged) {
	    	System.out.print(" "+ p);
	    }
	    System.out.println();
	}
//	Write a program to find the length of a string.
	public void StringLength(String str) {
	        int length = str.length();
	        System.out.println("The length of the string " +str+" is: " + length);
	}
//	Write a program to concatenate two strings.
	public void StringConcat(String str1,String str2) {
	        String result = str1.concat(str2);
	        System.out.println("Concatenated string: " + result);
	}
//	Write a program to compare two strings.
	public void StringCompare(String str1,String str2) {
	        boolean isEqual = str1.equals(str2);
	        System.out.println("The Strings are  " + (isEqual? "" : "Not") + " equal");
	}
//	Write a program to reverse a string.
	public void StringReverse(String str) {
	        String reversed = new StringBuilder(str).reverse().toString();
	        System.out.println("Reversed of  " +str+" | is: " + reversed);
	}
//	Write a program to check if a string is a palindrome.
	public void StringPalindrome(String str){
	        boolean isPalindrome = str.equals(new StringBuilder(str).reverse().toString());
	        System.out.println("The String "+str+" is " + (isPalindrome? "" : "Not") + " a palindrome");
	}
//	Write a program to find the frequency of each character in a string.
	public void StringFrequency(String str) {
	        Map<Character, Integer> frequencyMap = new HashMap<>();
	        for (char c : str.toCharArray()) {
	            frequencyMap.put(c, frequencyMap.getOrDefault(c, 0) + 1);
	        }
	        System.out.println("Character frequencies of  " +str+" is:");
	        for (Map.Entry<Character, Integer> entry : frequencyMap.entrySet()) {
	            System.out.print(entry.getKey() + ": " + entry.getValue() + " | ");
	        }
	        System.out.println();
	}
//	Write a program to count the number of vowels and consonants in a string.
	public void StringVowelConstCount(String str) {
	        int vowelCount = 0, constCount = 0;
	        for (char c : str.toLowerCase().toCharArray()) {
	            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
	                vowelCount++;
	            } else if (c >= 'a' && c <= 'z') {
	                constCount++;
	            }
	        }
	        System.out.println("The String  " +str+" has:");
	        System.out.println("Vowel count: " + vowelCount);
	        System.out.println("Consonant count: " + constCount);
	}
//	Write a program to convert a string to uppercase and lowercase.
	public void StringCase(String str) {
	        String upperCase = str.toUpperCase();
	        String lowerCase = str.toLowerCase();
	        System.out.println("Uppercase: " + upperCase);
	        System.out.println("Lowercase: " + lowerCase);
	}
//	Write a program to replace a character in a string.
	public void StringReplace(String str, char choice, char change) {
	        String replaced = str.replace(choice, change);
	        System.out.println("the String: "+ str + " had: "+choice+" replaced with: "+change+" result is:" + replaced);
	}
//	Write a program to find a substring in a string.
	public void SubstringSearch(String str, String sub) {
	        boolean found = str.contains(sub);
	        System.out.println("This String  " +str+" | " +(found? "does":"does not") + " contains the subString: "+sub);
	}
//	Define a class Person with attributes like name, age, and address. Create and display objects of this class.
	public void Person1(String name,int age,String address) {
		Person p = new Person(name,age,address);
		System.out.println("Person display");
		System.out.println(p.print());
	}
//	Define a class Rectangle with attributes length and breadth and methods to calculate area and perimeter. Create and display objects of this class.
	public void Rectangle(double length,double width) {
		Rectangle r = new Rectangle(length,width);
		System.out.println("Rectangle display:");
		System.out.println("area is "+r.area());
		System.out.println("perimeter is: "+r.perimeter());
		System.out.println(r.print());
	}
//	Define a class Circle with an attribute radius and methods to calculate area and circumference. Create and display objects of this class.
	public void Circle(double radius) {
		Circle c = new Circle(radius);
		System.out.println("Circle display: ");
		System.out.println("area: "+c.area());
		System.out.println("circumference: "+ c.circumference());
		System.out.println(c.print());
	}
//	Define a class Employee with attributes like name, id, and salary. Create and display objects of this class.
	public void Employee(String name, int id, double salary) {
		Employee e = new Employee(name,id,salary);
		System.out.println("Employee display: ");
		System.out.println(e.print());
	}
//	Define a class Student with attributes like name, roll number, and marks. Create and display objects of this class.
	public void Student(String name, int rollNumber,double marks) {
		Student s = new Student(name,rollNumber,marks);
		System.out.println("Student Display: ");
		System.out.println(s.print());
	}
//	Define a superclass Animal with a method makeSound(). Create subclasses Dog and Cat that override the makeSound() method.
	public void Animal() {
		System.out.println("Animals make noise");
		Cat c = new Cat();
		c.makeSound();
		Dog d = new Dog();
		d.makeSound();
	}
//	Define a superclass Shape with a method draw(). Create subclasses Circle, Rectangle, and Triangle that override the draw() method.
	public void Shape() {
		System.out.println("shapes: ");
		subCircle c = new subCircle();
		subRectangle r = new subRectangle();
		subTriangle t = new subTriangle();
		c.draw();
		System.out.println("rectangle drawing");
		r.draw();
		System.out.println("triangle drawing");
		t.draw();
	}
//	Define a superclass Vehicle with attributes like make and model. Create subclasses Car and Bike with additional attributes and methods.
	public void Vehicle(String make,String model, int wheels,String color) {
		Vehicle v = new Vehicle(make,model);
		System.out.println("vehicles");
		System.out.println(v.toString());
		Car c = new Car(v,wheels);
		System.out.println(c.toString());
		Bike b = new Bike(v,color);
		System.out.println(b.toString());
	}
//	Define a superclass Person with attributes like name and age. Create subclasses Teacher and Student with additional attributes and methods.
	public void PersonSub(String name, int age, String teacher, String education) {
		Person p = new Person(name,age);
		System.out.println("super Person");
		System.out.println(p.print());
		Teacher t = new Teacher(p,teacher);
		System.out.println(t.toString());
		subStudent s = new subStudent(p,education);
		System.out.println(s.toString());
	}
//	Demonstrate method overloading with a class Calculator that has multiple add() methods for different parameter types.
	public void Calculator(Number a, Number b, Number c) {
		Calculator cal = new Calculator();
		System.out.println("calculatr with differnt adds");
		System.out.println("adding two numbers"+ cal.add(a, b));
		System.out.println("adding three numbers"+ cal.add(a, b, c));
	}
//	Demonstrate method overriding with a superclass Shape and its subclasses Circle, Rectangle, and Triangle.
	public void Shape1() {
		System.out.println("shapes: ");
		subCircle c = new subCircle();
		subRectangle r = new subRectangle();
		subTriangle t = new subTriangle();
		c.draw();
		System.out.println("rectangle drawing");
		r.draw();
		System.out.println("triangle drawing");
		t.draw();
	}
//	Define an abstract class Animal with an abstract method makeSound(). Create subclasses Dog and Cat that implement the makeSound() method.
	public void Animal1() {
		System.out.println("Animals replace make sound");
		Cat c = new Cat();
		c.makeSound();
		Dog d = new Dog();
		d.makeSound();
	}
//	Define an interface Shape with methods calculateArea() and calculatePerimeter(). Create classes Circle, Rectangle, and Triangle that implement the Shape interface.
	public void iShape(double radius,double length,double width, double a, double b, double c) {
		System.out.println("Shape with interface");
		iCircle ic = new iCircle(radius);
		System.out.println("circle area: "+ ic.calculateArea());
		System.out.println("circle perimeter: "+ ic.calculatePerimeter());
		iRectangle r = new iRectangle(length,width);
		System.out.println("rectangle area: "+r.calculateArea());
		System.out.println("rectangle perimeter: "+r.calculatePerimeter());
		iTriangle t = new iTriangle(a,b,c);
		System.out.println("Triangle area: "+t.calculateArea());
		System.out.println("Triangle perimeter: "+t.calculatePerimeter());
	}
//	Define a class BankAccount with private attributes like accountNumber and balance. Provide public methods to access and modify these attributes.
	public void BankAccount(int id, double bal) {
		BankAccount b = new BankAccount(id,bal);
		System.out.println("bank account");
		b.setAccountNumber(5);
		System.out.println("new account number: "+ b.getAccountNumber());
		b.setBalance(999);
		System.out.println("new balance: "+b.getBalance());
	}
//	Write a program to handle ArrayIndexOutOfBoundsException.
	public void ExceptionIndex() {
		int[] ary = {5,6};
		System.out.println("trying to get value at 5 with array of length 2");
		try {
			System.out.println(ary[5]);
		} catch(Exception e) {
			System.out.println("failed index out of bounds");
		}
	}
//	Write a program to handle NumberFormatException.
	public void ExceptionNumber() {
		String str = "words";
		System.out.println("trying to change a String into a number");
		try {
			int a = Integer.parseInt(str);
		} catch(Exception e) {
			System.out.println("failed unable to change value to int");
		}
	}
//	Write a program to handle NullPointerException.
	public void ExceptionNull() {
		String str = null;
		System.out.println("trying to get value from a null string");
		try {
			System.out.println(str.length());
		} catch(Exception e) {
			System.out.println("failed string is null and length cannot be found");
		}
	}
//	Write a program that uses try, catch, and finally blocks.
	public void trying() {
		int[] ary = {5,6};
		System.out.println("trying to give value at 5 and new value with array of length 2");
		try {
			ary[5] = 7;
		} catch(Exception e) {
			System.out.println("failed index out of bounds");
		} finally {
			System.out.println("Printing array in finally block");
			for(int i : ary) {
				System.out.print(i + " ");
			}
			
		}
		System.out.println();
	}
//	Write a program to create and use a custom exception InvalidAgeException.
	public void ExceptionCustom(boolean check) {
		System.out.println("custom exception: if false no exception will be thrown");
		if(check) {
			try {
				throw new CustomException("this is the custom exception message");
			} catch(CustomException e) {
				System.out.println(e.getMessage());
			}
		}
	}
//	Write a program to demonstrate the use of ArrayList.
	public void FrameArrayList() {
		ArrayList<String> ls = new ArrayList<String>();
		System.out.println("demonstrating ArrayList");
		System.out.println("adding two items to list");
		ls.add("first item");
		ls.add("second item");
		System.out.println("printing ArrayList");
		System.out.println(ls);
	}
//	Write a program to demonstrate the use of LinkedList.
	public void FrameLinkedList() {
		LinkedList<Integer> ls = new LinkedList<Integer>();
		System.out.println("demonstrating LinkedList");
		System.out.println("adding two items");
		ls.add(10);
		ls.add(20);
		System.out.println("printing Linkedlist");
		System.out.println(ls);
	}
//	Write a program to demonstrate the use of HashSet.
	public void FrameHashSet() {
		System.out.println("demonstraiting HashSet");
		HashSet<Integer> set = new HashSet<Integer>();
		System.out.println("adding three items with duplicates");
		set.add(5);
		set.add(6);
		set.add(5);
		System.out.println("printing hashSet");
		System.out.println(set);
	}
//	Write a program to demonstrate the use of TreeSet.
	public void FrameTreeSet() {
		System.out.println("demonstraiting TreeSet");
		HashSet<Integer> set = new HashSet<Integer>();
		System.out.println("adding three items with duplicates");
		set.add(5);
		set.add(6);
		set.add(5);
		System.out.println("printing hashTree");
		System.out.println(set);
	}
//	Write a program to demonstrate the use of HashMap.
	public void FrameHashMap() {
		System.out.println("Demonstrating HashMap");
		HashMap<String,Integer> map = new HashMap<String, Integer>();
		System.out.println("adding three items with duplicate values and keys");
		map.put("first item", 26);
		map.put("second item", 26);
		map.put("first item", 15);
		System.out.println("printing HashMap");
		System.out.println(map);
	}
//	Write a program to demonstrate the use of TreeMap.
	public void FrameTreeMap() {
		System.out.println("Demonstrating TreeMap");
		HashMap<String,Integer> map = new HashMap<String, Integer>();
		System.out.println("adding three items with duplicate values");
		map.put("first item", 26);
		map.put("second item", 26);
		map.put("third item", 15);
		System.out.println("printing TreeMap");
		System.out.println(map);
	}
//	Write a program to read content from a file.
//	Write a program to write content to a file.
//	Write a program to copy content from one file to another.
//	Write a program to read and write objects to a file using serialization.
//	Write a program to create and run multiple threads by extending the Thread class.
	public void ThreadExtend() throws Exception {
		System.out.println("runing multi threads by extending");
		multiThread t1 = new multiThread();
		multiThread t2 = new multiThread();
		t1.start();
		t2.start();
		t1.sleep(500);
	}
//	Write a program to create and run multiple threads by implementing the Runnable interface.
	public void ThreadInter() throws Exception {
		System.out.println("runing multi threads by implementing");
		Thread t1 = new Thread(new imultiThread());
		Thread t2 = new Thread(new imultiThread());
		t1.start();
		t2.start();
		t1.sleep(500);
	}
//	Write a program to demonstrate thread synchronization using synchronized methods.
	public void ThreadSyncMethod() {
		System.out.println("runing multi threads with synchronized methods");
		Threadsync t = new Threadsync();
		Thread t1 = new Thread(() -> t.loop());
		Thread t2 = new Thread(() -> t.loop());
		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println();
	}
//	Write a program to demonstrate thread synchronization using synchronized blocks.
	public void ThreadSyncBlocks() {
		System.out.println("runing multi threads with synchronized blocks");
		Threadsync t = new Threadsync();
		Thread t1 = new Thread(() -> t.loop2Caller());
		Thread t2 = new Thread(() -> t.loop2Caller());
		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println();
		
	}
//	Write a program to demonstrate inter-thread communication using wait() and notify() methods.
	public void Threadinter() throws InterruptedException {
		System.out.println("demonstrating inter-thread comunication");
		Threadsync t = new Threadsync();
		Thread t1 = new Thread(() -> {
			try {
				t.waiter();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			System.out.println("thread 1 is done");
		});
		
		Thread t2 = new Thread(() ->{
			t.sender();
			System.out.println("thread 2 is done and sending signal");
		});
		t1.start();
		t2.start();
		System.out.println();
		t2.sleep(500);
	}
//	Write a program to demonstrate the use of lambda expressions.
	public void lambda() {
		System.out.println("demonstrating lambda with foreach");
		List<String> ls = Arrays.asList("Using ","For ","Each ");
		ls.forEach( (a) -> System.out.print(" "+ a));
		System.out.println();
	}
//	Write a program to demonstrate the use of streams for filtering and mapping.
	public void Streams() {
		List<Integer> ls = Arrays.asList(1,2,2,3,4,5,6,6);
		System.out.println("demonstrating filter and mapping with streams");
		System.out.println("filtering only even, then adding one to each number with map");
		ls.stream().filter((a) -> a % 2 == 0).map((a) -> a+1).forEach((a) -> System.out.print(" | "+a));
		System.out.println();
	}
//	Write a program to demonstrate the use of method references.
	public void MethodRef() {
		System.out.println("demonstrating method references");
		System.out.println("calling print over an array");
		List<Integer> ls = Arrays.asList(9,8,7,6,5,4,3,2,1);
		ls.forEach(System.out::print);
		System.out.println();
	}
//	Write a program to demonstrate the use of default and static methods in interfaces.
	public void defaultStatic() {
		DefaultStaticChild o = new DefaultStaticChild();
		System.out.println("demonstrating calling default from interface");
		o.def();
		System.out.println("calling static from interface");
		o.print();
	}
//	Write a program to demonstrate the use of the Optional class.
//	Write a program to demonstrate the use of enums.
//	Write a program to demonstrate the use of nested classes.
//	Write a program to demonstrate the use of generics.
//	Write a program to demonstrate the use of annotations.
//	Write a program to demonstrate the use of the Reflection API.
//	Write a program to demonstrate the use of the Stream API for parallel processing.
//	Write a program to demonstrate the use of the CompletableFuture class for asynchronous programming.
//	Write a program to connect to a database.
//	Write a program to insert data into a database.
//	Write a program to update data in a database.
//	Write a program to delete data from a database.
//	Write a program to retrieve data from a database.
//	Write a program to use prepared statements to insert and retrieve data from a database.
//	Write a program to use callable statements to call stored procedures.
//	Write a program to calculate the area of different shapes using method overloading.
//	Write a program to demonstrate the use of a final keyword with a variable, method, and class.
//	Write a program to demonstrate the use of a static keyword with a variable and method.
//	Write a program to demonstrate the use of this keyword.
//	Write a program to demonstrate the use of super keyword.
//	Write a program to implement a simple calculator using switch-case statements.
//	Write a program to demonstrate the use of a singleton class.
//	Write a program to demonstrate the use of a factory design pattern.
//	Write a program to demonstrate the use of a builder design pattern.
}
