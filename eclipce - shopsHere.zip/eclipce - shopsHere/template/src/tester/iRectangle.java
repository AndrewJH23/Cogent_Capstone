package tester;

public class iRectangle implements ShapeInterface{
	private double length;
	private double width;
	
	iRectangle(double length, double width){
		this.length =length;
		this.width = width;
	}
	
	@Override
	public double calculateArea() {
		return this.length * this.width;		
	}

	@Override
	public double calculatePerimeter() {
		return this.length*2 + this.width*2;
	}

}
