package practiceQ.Rectangle;

import java.util.Scanner;

public class TestRectangle {
		
	public static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		Rectangle r = new Rectangle();
		System.out.println("printing default rectangle area: "+ r.calArea());
		System.out.println("Enter height then width");
		double Height = input.nextDouble();
		System.out.println();
		double Width = input.nextDouble();
		Rectangle r2 = new Rectangle(Height,Width);
		System.out.println("printing rectangle area: "+ r2.calArea());
	}
}
