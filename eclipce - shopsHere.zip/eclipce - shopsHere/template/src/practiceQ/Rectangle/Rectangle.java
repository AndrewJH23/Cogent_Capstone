package practiceQ.Rectangle;

public class Rectangle {
	private double height;
	private double width;
	
	Rectangle(){
		System.out.println("no args construct");
		this.height=5;
		this.width=5;
	}
	
	Rectangle(double h, double w){
		System.out.println("args construct");
		this.height=h;
		this.width=w;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}
	
	public double calArea() {
		return this.height*this.width;
	}
	
}
