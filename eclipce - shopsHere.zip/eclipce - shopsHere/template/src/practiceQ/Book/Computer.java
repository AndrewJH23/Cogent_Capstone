package practiceQ.Book;

public class Computer extends Book{
	private String type;
	
	public Computer(int bookNo, String title, String publication, String author, float price, String type) {
		super(bookNo, title, publication, author, price);
		// TODO Auto-generated constructor stub
		this.type = type;
	}

	public String getNetworking() {
		return type;
	}

	public void setNetworking(String networking) {
		type = networking;
	}

	@Override
	public String toString() {
		return super.toString()+", Computer [Networking=" + type + "]";
	}
	
	
	
}
