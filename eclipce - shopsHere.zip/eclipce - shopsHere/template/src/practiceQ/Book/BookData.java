package practiceQ.Book;

public class BookData {
	private Book[] books;
	private static int index;
	
	static {
		index = 0;
	}
	
	public void setBook(int bookNo, String title, String publication, String author, float price, String type) {
		Book b = new Book(bookNo, title, publication, author, price);
		books[index] = b;
		index++;
	}
	
	public void printBooks() {
		for(Book b: books) {
			System.out.println(b.toString());
		}
	}
	
	public String searchByNo(int bookNo) {
		for(Book b: books) {
			if(b.getBookNo() == bookNo) {
				return b.toString();
			}
		}
		return "no book found";
	}
	
	public String searchByAuthor(String author) {
		for(Book b: books) {
			if(b.getAuthor().equals(author)) {
				return b.toString();
			}
		}
		return "no book found";
	}
	
}
