package practiceQ.Book;

public class Mathematics extends Book{
	private String type;
	
	public Mathematics(int bookNo, String title, String publication, String author, float price, String type) {
		super(bookNo, title, publication, author, price);
		// TODO Auto-generated constructor stub
		this.type = type;
	}

	public String getDiscrete() {
		return type;
	}

	public void setDiscrete(String discrete) {
		this.type = discrete;
	}

	@Override
	public String toString() {
		return super.toString()+", Mathematics [type=" + type + "]";
	}
	
	
	
}
