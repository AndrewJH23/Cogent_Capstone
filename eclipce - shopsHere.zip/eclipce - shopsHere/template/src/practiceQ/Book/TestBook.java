package practiceQ.Book;

import java.util.Scanner;

public class TestBook {
	private static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		Book[] books = new Book[4];
		
		System.out.println("enter Computer Book:");
		System.out.println("BookNo");
		int BookNo = input.nextInt();
		input.nextLine();
		System.out.println("title");
		String title = input.nextLine();
		System.out.println("publication");
		String publication = input.nextLine();
		System.out.println("Author");
		String author = input.nextLine();
		System.out.println("price");
		float price = input.nextFloat();
		input.nextLine();
		System.out.println("networking");
		String networking = input.nextLine();
		
		Book c = new Computer(BookNo, title, publication, author, price, networking);
		System.out.println(c.toString());
		
		System.out.println("enter Math Book:");
		System.out.println("BookNo");
		 BookNo = input.nextInt();
		input.nextLine();
		System.out.println("title");
		 title = input.nextLine();
		System.out.println("publication");
		 publication = input.nextLine();
		System.out.println("Author");
		 author = input.nextLine();
		System.out.println("price");
		 price = input.nextFloat();
		input.nextLine();
		System.out.println("discrete");
		String discrete = input.nextLine();
		
		Book m = new Mathematics(BookNo, title, publication, author, price, discrete);
		System.out.println(m.toString());
		
		Book c2 = new Computer(5, "title", "pub", "auth", 1, "net");
		Book m2 = new Mathematics(4, "title2", "pub2", "auth2", 6, "des");
		
		books[0] = c;
		books[1] = c2;
		books[2] = m;
		books[3] = m2;
		System.out.println("printing list");
		for(Book b: books) {
			System.out.println(b.toString());
		}
		
		
	}
}
