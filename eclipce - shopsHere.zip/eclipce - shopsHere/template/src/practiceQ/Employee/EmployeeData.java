package practiceQ.Employee;

import java.util.Scanner;

public class EmployeeData {
	
	private static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		Employee e = new Employee();
		System.out.println("default values of employee: "+e.toString());
		System.out.println("Enter each field");
		int empNo = input.nextInt();
		input.next();
		String empName = input.nextLine();
		int empsal = input.nextInt();
		Employee e2 = new Employee(empNo,empName,empsal);
		System.out.println("Entered values of employee: "+e2.toString());
		
	}
}
