package practiceQ.Employee;

public class Employee {
	private int empNo;
	private String empName;
	private int empSal;
	
	Employee(){
		this.empNo = 1231;
		this.empName = "Manjiri";
		this.empSal = 25000;
	}

	public Employee(int empNo2, String empName2, int empsal2) {
		// TODO Auto-generated constructor stub
		this.empNo = empNo2;
		this.empName = empName2;
		this.empSal = empsal2;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	
	
	
	
}
