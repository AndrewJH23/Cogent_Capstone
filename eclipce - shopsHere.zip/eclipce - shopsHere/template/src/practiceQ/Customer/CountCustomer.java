package practiceQ.Customer;

import java.util.Scanner;

public class CountCustomer {
	
	private static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		System.out.println("initial custCount: "+Customer.getCustCount());
		Customer c1 = new Customer(1,"first");
		Customer c2 = new Customer(2,"second");
		Customer c3 = new Customer(3,"third");
		
		System.out.println("enter name, or done when done");
		String name = "done";
		int i = 4;
		do {
			name = input.nextLine();
			Customer c = new Customer(i,name);
			i++;
			System.out.println(name + " count: "+Customer.getCustCount());
		}while(!name.equals("done"));
		
		System.out.println("new custCount: "+Customer.getCustCount());
		
	}
}
