package com.example.main;

import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class CustomerItemWriter implements ItemWriter<Customer>{

	private final CustomerRepo repo;
	
	@Override
	public void write(Chunk<? extends Customer> chunkList) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Writer Thread: "+Thread.currentThread().getName());
		repo.saveAll(chunkList);
		
		
	}
	
}
