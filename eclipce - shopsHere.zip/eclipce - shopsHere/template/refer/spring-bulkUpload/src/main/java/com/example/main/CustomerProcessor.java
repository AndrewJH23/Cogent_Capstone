package com.example.main;

import org.springframework.batch.item.ItemProcessor;

public class CustomerProcessor implements ItemProcessor<Customer, Customer>{

	@Override
	public Customer process(Customer item) throws Exception {
		// TODO Auto-generated method stub
		int age = Integer.parseInt(item.getAge());
		if(age >= 18) {
			return item;
		}
		return null;
	}
	
}
