package com.example.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.SkipListener;

public class StepSkipListener implements SkipListener<Customer, NumberFormatException>{
	
	public static Logger log = LoggerFactory.getLogger(StepSkipListener.class);
	
	@Override
	public void onSkipInProcess(Customer item, Throwable t) {
		// TODO Auto-generated method stub
		log.info("skipped due to exception");
	}
	
	@Override
	public void onSkipInRead(Throwable t) {
		// TODO Auto-generated method stub
		log.info(t.getMessage());
		
	}
	
	@Override
	public void onSkipInWrite(NumberFormatException item, Throwable t) {
		// TODO Auto-generated method stub
		log.info(t.getMessage());
		
	}
}
