package com.example.main;

import java.io.File;
import java.util.List;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/batch")
@RequiredArgsConstructor
public class BatchController {

	private final JobLauncher jobLauncher;
	private final Job job;
	private final CustomerRepo customerRepository;

	@PostMapping("/importData")
	public void startBatch() {

		try {

			JobParameters jobParameters = new JobParametersBuilder().addLong("startAt", System.currentTimeMillis())
					.toJobParameters();

			JobExecution execution = jobLauncher.run(job, jobParameters);
			if (execution.getExitStatus().getExitCode().equals(ExitStatus.COMPLETED)) {
				System.out.println("batch uploaded");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	@GetMapping("/")
	public List<Customer> getAllData() {

		return customerRepository.findAll();
	}

}

