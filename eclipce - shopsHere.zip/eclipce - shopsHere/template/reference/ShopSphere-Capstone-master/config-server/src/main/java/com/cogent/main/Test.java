package com.cogent.main;

public class Test {
	public void main() {
		System.out.println("I am not maind");
	}
}
