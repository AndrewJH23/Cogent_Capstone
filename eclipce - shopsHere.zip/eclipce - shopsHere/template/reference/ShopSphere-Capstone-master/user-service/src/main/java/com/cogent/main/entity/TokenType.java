/**
 * @author: Tenzin 
 * @date : Feb 13, 2024
 */
package com.cogent.main.entity;

public enum TokenType {
	BEARER
}
