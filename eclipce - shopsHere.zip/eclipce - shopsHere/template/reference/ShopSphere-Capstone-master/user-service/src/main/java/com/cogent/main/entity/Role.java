/**
 * @author: Tenzin 
 * @date : Feb 12, 2024
 */
package com.cogent.main.entity;

public enum Role {
	USER, ADMIN
}
