package com.cogent.main.entity;

import com.cogent.main.dto.AddressDao;
import com.cogent.main.dto.NameDao;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
//
//@Entity
//@Builder
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class UserEntity {
//	
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private int id;
//	@Embedded
//	private NameDao name;
//	
//	private String email;
//	
//	@Embedded
//	private AddressDao address;
//	
//	
//}
