package com.example.service;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Dao.ProductDao;
import com.example.Repository.ProductRepository;
import com.example.entity.Product;

@Service
public class ProductServiceImp extends ProductService {

	@Autowired
	private ProductRepository repo;

	public List<ProductDao> getAllProduct() {
		//List<Product> ls = repo.findAll();
		return repo.findAll().stream().map((product) -> {
			ProductDao Dao = new ProductDao();
			Dao.setName(product.getName());
			Dao.setPrice(product.getPrice());
			return Dao;
		}).collect(Collectors.toList());
		//return lsDao;
	}

	public ProductDao getProductById(int id) {
		Product product = repo.findById(id).orElse(new Product(0, "no Product found",0.0f));
		return new ProductDao(product.getName(),product.getPrice());
	}

	public ProductDao saveProduct(ProductDao product) {
		Product p = Product.builder()
				.name(product.getName())
				.price(product.getPrice())
				.build();
		product = ProductDao.builder()
				.name(p.getName()).price(p.getPrice()).build();
		repo.save(p);
		return product;
	}

	public ProductDao updateProductById(int id, ProductDao product) {
		Optional<Product> p = repo.findById(id);
		if(!p.isEmpty()) {
			p.get().setName(product.getName());
			p.get().setPrice(product.getPrice());
			Product uP = repo.save(p.get());
			return ProductDao.builder().name(uP.getName()).price(uP.getPrice()).build();
		}
		return new ProductDao("no Product found",0.0f);
	}

	public ProductDao deleteProductById(int id) {
		Optional<Product> p = repo.findById(id);
	    if (p.isPresent()) {
	        repo.deleteById(id);
	        return ProductDao.builder().name(p.get().getName()).price(p.get().getPrice()).build();
	    }
	    return new ProductDao("no Product found",0.0f);
	}
}
