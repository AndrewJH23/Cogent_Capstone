package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Dao.ProductDao;
import com.example.entity.Product;
import com.example.service.ProductServiceImp;

@RestController
@RequestMapping("/api/v1/product")
public class ProductController {
	
	private ProductServiceImp service;
	
	public ProductController(ProductServiceImp service) {
		super();
		this.service = service;
	}
	
	@GetMapping("/")
	public List<ProductDao> getAllProduct(){
		return service.getAllProduct();
	}
	
	@GetMapping("/{id}")
	public ProductDao getProductById(@PathVariable("id") int id) {
		return service.getProductById(id);
	}
	
	@PostMapping("/")
	public ProductDao saveProduct(@RequestBody ProductDao product) {
		return service.saveProduct(product);
	}
	
	@PutMapping("/{id}")
	public ProductDao updateProductById(@PathVariable("id") int id,@RequestBody ProductDao product) {
		return service.updateProductById(id, product);
	}
	
	@DeleteMapping("/{id}")
	public ProductDao deleteProductById(@PathVariable("id") int id) {
		return service.deleteProductById(id);
	}
	
}
