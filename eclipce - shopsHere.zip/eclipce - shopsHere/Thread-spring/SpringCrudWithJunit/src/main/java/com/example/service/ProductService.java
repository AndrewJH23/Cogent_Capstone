package com.example.service;

import java.util.List;

import com.example.Dao.ProductDao;
import com.example.entity.Product;

public abstract class ProductService {

     public abstract List<ProductDao> getAllProduct();

     public abstract ProductDao getProductById( int id);

     public abstract ProductDao saveProduct( ProductDao product);

     public abstract ProductDao updateProductById( int id,  ProductDao product);

     public abstract ProductDao deleteProductById( int id);
}
