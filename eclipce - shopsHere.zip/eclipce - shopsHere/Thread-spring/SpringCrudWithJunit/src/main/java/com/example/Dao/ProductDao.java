package com.example.Dao;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

//data access object

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ProductDao {
	
	
	private String name;
	private float price;
}
