package com.example.main;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.example.Dao.ProductDao;
import com.example.service.ProductServiceImp;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;


//
//@WebMvcTest(SpringCrudWithJUnitApplicationTests.class)
@SpringBootTest
@AutoConfigureMockMvc
class SpringCrudWithJUnitApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private ProductServiceImp productService;
	private ProductDao product1;
	private ProductDao product2;
	private List<ProductDao> products = new ArrayList<ProductDao>();

	@BeforeEach
	void setUp() {
		product1 = new ProductDao( "pen", 5.6f);
		product2 = new ProductDao( "pencil", 3.2f);
		products.add(product1);
		products.add(product2);
		System.out.println("SetUp Executed");

	}

	@Test
	void getProductByID() throws Exception {
		System.out.println("Getting ----------------------");
		when(productService.getProductById(1))
		.thenReturn(ProductDao.builder()
				.name(product1.getName())
				.price(product1.getPrice()).build());
		
		mockMvc.perform(get("/api/v1/product/1"))
		.andDo(print()).andExpect(status().isOk());

	}
	@Test
	void createProduct() throws Exception
	{
		System.out.println("creating ----------------------");
		ObjectMapper om = new ObjectMapper();
		om.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		ObjectWriter ow = om.writer().withDefaultPrettyPrinter();
		String json  = ow.writeValueAsString(product1);
		
		when(productService.saveProduct(product1))
		.thenReturn(product1);
		
		mockMvc.perform(post("/api/v1/product/")
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
		.andDo(print()).andExpect(status().isOk());
		
	}
	
	@Test
	void putProduct() throws Exception {
		System.out.println("updating ----------------------");
		ProductDao Dao = new ProductDao("pencil",9.9f);
		ObjectMapper om = new ObjectMapper();
		om.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		ObjectWriter ow = om.writer().withDefaultPrettyPrinter();
		String json  = ow.writeValueAsString(Dao);
		
		when(productService.getProductById(1))		
		.thenReturn(Dao);
		mockMvc.perform(put("/api/v1/product/1")
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
		.andDo(print()).andExpect(status().isOk());
	}
	
	@Test
	void deleteProduct() throws Exception{
		System.out.println("deleting ----------------------");
		when(productService.getProductById(1))
		.thenReturn(ProductDao.builder()
				.name(product1.getName())
				.price(product1.getPrice()).build());
		
		mockMvc.perform(delete("/api/v1/product/1"))
		.andDo(print()).andExpect(status().isOk());
	}
	
	
	
	
	
	
	
	
	

}
