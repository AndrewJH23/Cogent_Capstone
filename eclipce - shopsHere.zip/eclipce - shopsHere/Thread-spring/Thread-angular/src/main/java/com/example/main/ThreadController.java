package com.example.main;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/crud")
public class ThreadController {
	
	@Autowired
	private ThreadService service;
	
	//get,post,put,delete crud
	
	@GetMapping("/")
	public List<Messager> getMessager() {
		return service.getMessager();
	}
	
	@PostMapping("/add")
	public Messager saveMessage(@RequestBody Messager messager) {
		return service.saveMessage(messager);
	}
	
	@PutMapping("/{id}")
	public Messager putMessage(@PathVariable int id, @RequestBody Messager message) {
		//TODO: process PUT request	
		return service.updateMessage(id,message);
	}
	
	@DeleteMapping("/{id}")
	public String deleteMessage(@PathVariable int id) {
		return service.delMessage(id);
	}

}
