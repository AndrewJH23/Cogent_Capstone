package com.example.main;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ThreadService {

	@Autowired
	private MessagerRepo repo;


	public List<Messager>  getMessager() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}


	public Messager saveMessage(Messager messager) {
		// TODO Auto-generated method stub
		return repo.save(messager);
	}


	public Messager updateMessage(int id, Messager message) {
		// TODO Auto-generated method stub
		Messager temp = repo.findById(id).orElse(null);
		if(temp != null) {
			temp.setMessage(message.getMessage());	
		}
		return temp;
	}

	public String delMessage(int id) {
		// TODO Auto-generated method stub
		try {
			repo.deleteById(id);
		} catch (Exception e) {
			// TODO: handle exception
			return e.getMessage();
		}
		return "message deleted";
	}
	
}
