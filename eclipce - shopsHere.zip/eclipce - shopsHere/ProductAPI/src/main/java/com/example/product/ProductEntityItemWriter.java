package com.example.product;

import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;


@Component
@RequiredArgsConstructor
public class ProductEntityItemWriter implements ItemWriter<ProductEntity>{
	private final ProductRepository repo = null;
	
	@Override
	public void write(Chunk<? extends ProductEntity> chunkList) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Writer Thread: "+Thread.currentThread().getName());
		repo.saveAll(chunkList);
		
		
	}
}
