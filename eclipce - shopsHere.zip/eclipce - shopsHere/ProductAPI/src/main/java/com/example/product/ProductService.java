package com.example.product;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import org.springframework.batch.core.Job;
import org.springframework.batch.core.launch.JobLauncher;




@Service
public class ProductService
{
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private JobLauncher jobLauncher;
	@Autowired
	private Job job;


	public List<ProductEntity> getAllProducts()
	{
		return productRepository.findAll();
	}

	public ProductEntity addNewProduct(ProductEntity productEntity)
	{
		return productRepository.save(productEntity);
	}

	public ProductEntity getOneProduct(int id)
	{
		return productRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Product does not Exist"));
	}

	public ProductEntity updateProduct(ProductEntity productEntity, int id)
	{
		productEntity.setId(id);
		return productRepository.save(productEntity);
	}

	public void deleteProduct(int id)
	{
		productRepository.deleteById(id);
	}

	public List<ProductEntity> getByCategory(String category)
	{
		return productRepository.findAllByCategory(category);
	}

	public List<String> getCategories()
	{
		return productRepository.findCategories();
	}
	
	public void startBatch(MultipartFile multiPartFile) throws Exception {		
		try {
			String fileName = UUID.randomUUID().toString()+"_"+multiPartFile.getOriginalFilename();
			String targetDirectory = "src/main/resource/file_location/";
			Path filePath = Paths.get(targetDirectory,fileName);
			multiPartFile.transferTo(filePath);

			JobParameters jobParameters = new JobParametersBuilder()
					.addLong("startAt", System.currentTimeMillis())
					.toJobParameters();

			JobExecution execution = jobLauncher.run(job, jobParameters);
			if (execution.getExitStatus().getExitCode().equals(ExitStatus.COMPLETED)) {
				System.out.println("batch uploaded");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
