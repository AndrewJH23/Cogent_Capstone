package com.example.product;

import org.springframework.batch.item.ItemProcessor;

public class ProductProcessor implements ItemProcessor<ProductEntity, ProductEntity>{

	@Override
	public ProductEntity process(ProductEntity item) throws Exception {
		// TODO Auto-generated method stub
		double price = item.getPrice();
		if(price >= 1) {
			return item;
		}
		return null;
	}
	
}