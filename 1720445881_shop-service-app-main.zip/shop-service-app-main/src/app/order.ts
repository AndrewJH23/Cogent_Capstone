export interface Order{
    id: number,
    userId: number,
    products: string,
    shippingDetails: string,
    total: number
}